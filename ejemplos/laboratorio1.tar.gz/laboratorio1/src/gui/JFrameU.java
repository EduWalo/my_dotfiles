package gui;

import java.awt.Color;

import javax.swing.JFrame;

public class JFrameU extends JFrame{
	
	public JFrameU() {
		super();
	}
	
	public void contruirse(){
		this.setOpacity(0.3f);
		this.setUndecorated(true);
		this.setBackground(Color.magenta);
		this.setVisible(true);
	}
	public static void main(String[] args) {
		Color c1 = Color.white;
		Color c2 = Color.WHITE;
		
		System.out.println("R:" + c1.getRed() + " G:" + c1.getGreen() + " B:" + c1.getBlue() );
		System.out.println("R:" + c2.getRed() + " G:" + c2.getGreen() + " B:" + c2.getBlue() );
	}
}
