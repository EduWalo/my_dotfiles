package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class Loteria {


	/**+
	 * Contstructor
	 */
	public Loteria() {
		initialize();
	}

	/***
	 * Se encargara de inicializar la interfaz
	 */
	public void initialize() {
		// JFRAME
		JFrame window = new JFrame();
		window.setSize(900, 400);
		window.setLocationRelativeTo(null);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setLayout(new BorderLayout());

		////////////////////////////////////
		//             NORTH              //
		////////////////////////////////////
		//    //                     //   //
		//    //                     //   //
		//    //                     //   //
		//LEFT//      CENTER         //RIG//
		//    //                     //   //
		//    //                     //   //
		////////////////////////////////////
		//              SOUTH             //
		////////////////////////////////////

		// paneles 
		JPanel panelCentral = new JPanel();
		JPanel panelFoother = new JPanel();

		// panel central
		panelCentral.setLayout(new GridLayout(4, 6, 2, 2));
		panelCentral.setOpaque(true);
		panelCentral.setBackground(new Color(234,244,211));
		//		panelCentral.setBackground(new Color(153,70,54));
		// agregar panel central en el centro de la ventana
		window.add(panelCentral, BorderLayout.CENTER);

		// panelafooter
		panelFoother.setLayout(new GridLayout(1, 2));
		panelFoother.setOpaque(true);
		panelFoother.setBackground(new Color(166,177,255));
		// agregamos el panel inferior
		window.add(panelFoother,BorderLayout.SOUTH);


		// array de lo qeu yo quiera
		Object [][] elemntos = new Object[4][6];


		// matriz de botones
		// filas
		for (int i = 0; i < 4; i++) {
			// columnas
			for (int j = 0; j < 6; j++) {
				if (j == 0) {
					JLabel lbl = new JLabel("LBL");
					lbl.setFont(lbl.getFont().deriveFont(Font.BOLD,20));
					panelCentral.add(lbl);
					elemntos[i][j] = lbl;
				}else {
					JButton jbt = new JButton("");
					jbt.setBackground(new Color(36, 32, 56));
					jbt.setForeground(new Color(234, 244, 211));
					jbt.setFont(jbt.getFont().deriveFont(Font.BOLD,18));
					panelCentral.add(jbt);
					elemntos[i][j] = jbt;
				}
			}

		}

		// cambiar texto de las etiquetas
		((JLabel)elemntos[0][0]).setText("Premio mayor");
		((JLabel)elemntos[1][0]).setText("Primer seco");
		((JLabel)elemntos[2][0]).setText("Segundo seco");
		((JLabel)elemntos[3][0]).setText("Tercer Seco");

		// botones de interaciion 
		JButton btnJugar = new JButton("Jugar");
		btnJugar.setBackground(new Color(42, 145, 52));
		btnJugar.setForeground(Color.white);
		btnJugar.setFont(btnJugar.getFont().deriveFont(Font.BOLD,16));
		btnJugar.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent arg0) {
				jugarLoteria(elemntos);
			}
		});

		JButton btnLimpiar = new JButton("Limpiar");
		btnLimpiar.setBackground(new Color(2, 108, 124));
		btnLimpiar.setForeground(Color.white);
		btnLimpiar.setFont(btnJugar.getFont().deriveFont(Font.BOLD,16));
		btnLimpiar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				limpiarLoteria(elemntos);
			}
		});

		// agregar botonoes al footer
		panelFoother.add(btnJugar);
		panelFoother.add(btnLimpiar);
		// mostrar
		window.setVisible(true);
	}

	/***
	 * Funcion que me permite insertar numeros random en los botones
	 */

	private void jugarLoteria(Object [][] elem) {
		//filas
		for (int i = 0; i < 4; i++) {
			// columnas
			for (int j = 1; j < 6; j++) {
				//recorrer cada elemento
				int balota =  (int) Math.floor(Math.random()*99);
				((JButton)elem[i][j]).setText(  String.valueOf(balota) ); 
			}

		}
	}

	/**
	 * Limpia cada uno de los botones del panel
	 * Se recorre cada elemento sin la primera, porque la priemra columna 
	 * es de las etuquetas
	 * y a cada elemento se le asigna como texto vacio ""
	 */

	private void limpiarLoteria(Object [][] elem) {
		//filas
		for (int i = 0; i < 4; i++) {
			// columnas
			for (int j = 1; j < 6; j++) {
				//recorrer cada elemento
				((JButton) elem[i][j]).setText(  "" ); 
			}

		}
	}

	/**
	 * declaración de los objetos a usar
	 * 
	 */
	
	//	contenido;

}
